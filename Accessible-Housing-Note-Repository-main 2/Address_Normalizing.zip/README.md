# Address Normalizer — Accessible Living Chrome Extension

Normalizes messy, abbreviated, or handwritten addresses into clean standardized formats using **Gemini AI**.

---

## Setup

1. **Get a Gemini API key** at [https://aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey)
2. Open `chrome://extensions` → Developer Mode → **Load unpacked** → select this folder
3. Open the extension, expand **API Key Settings**, paste your key, and click **Save**

---

## How to use

### Option A — Type or paste
1. Paste a raw address into the text box (or click ⎘ Paste)
2. Pick your output format: USPS / Multi-line / One-line / CSV
3. Select a country hint (helps AI with non-US addresses)
4. Click **Normalize Address**
5. Review the result and confidence level, check any flagged issues
6. Click **Copy Address**, **Copy JSON**, or **Copy CSV**

### Option B — Right-click any text on a webpage
1. Select an address on any webpage
2. Right-click → **"Normalize address with AI"**
3. The extension opens with the selected text pre-filled

---

## Output formats

| Format | Example |
|--------|---------|
| **USPS** | `123 MAIN ST APT 4B`<br>`SPRINGFIELD IL 62701` |
| **Multi-line** | `123 Main Street`<br>`Apt 4B`<br>`Springfield, IL 62701` |
| **One-line** | `123 Main Street, Apt 4B, Springfield, IL 62701` |
| **CSV** | `123 Main Street,Apt 4B,Springfield,IL,62701,US` |

---

## Confidence levels

- ✓ **High** — Address is clearly complete and valid
- ~ **Medium** — Mostly clear, but something was guessed (e.g. zip code inferred from city)
- ⚠ **Low** — Significant info missing or unclear — check the Issues section

---

## Files

| File | Purpose |
|------|---------|
| `manifest.json` | Chrome extension config |
| `background.js` | Right-click context menu handler |
| `popup.html` | 3-screen UI |
| `popup.css` | Dark utilitarian styles |
| `popup.js` | Logic: Gemini API, formatting, rendering |

---

## Customization

**Add more output formats** — add a button to `.format-grid` in `popup.html` and handle the new `data-fmt` key in `renderResult()` in `popup.js`.

**Change how addresses are structured** — edit the `prompt` string inside `normalizeAddress()` in `popup.js`. You can tell Gemini to expect a specific regional format or always output certain fields.
