// ══════════════════════════════════════════════
//  Address Normalizer — popup.js
//  Uses Gemini to parse and standardize addresses.
// ══════════════════════════════════════════════

// ── Config ───────────────────────────────────
const GEMINI_MODEL   = "gemini-1.5-flash";
const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`;

// ── State ────────────────────────────────────
let selectedFormat = "usps";
let lastResult     = null;   // parsed address object from AI

// ── DOM refs ─────────────────────────────────
const screens = {
  main:       document.getElementById("screen-main"),
  processing: document.getElementById("screen-processing"),
  result:     document.getElementById("screen-result"),
};

const rawInput        = document.getElementById("raw-input");
const apiKeyInput     = document.getElementById("api-key-input");
const procStatus      = document.getElementById("proc-status");
const resultDisplay   = document.getElementById("result-display");
const confidenceBadge = document.getElementById("confidence-badge");
const componentsGrid  = document.getElementById("components-grid");
const issuesBox       = document.getElementById("issues-box");
const issuesList      = document.getElementById("issues-list");
const copyConfirm     = document.getElementById("copy-confirm");

// ── Screen helper ─────────────────────────────
function showScreen(name) {
  Object.values(screens).forEach(s => s.classList.remove("active"));
  screens[name].classList.add("active");
}

// ── Init ──────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  // Load saved key
  chrome.storage.local.get(["geminiApiKey", "pendingAddress"], (result) => {
    if (result.geminiApiKey) apiKeyInput.value = result.geminiApiKey;

    // Pre-fill if triggered via right-click context menu
    if (result.pendingAddress) {
      rawInput.value = result.pendingAddress;
      chrome.storage.local.remove("pendingAddress");
    }
  });
  showScreen("main");
});

// ── Format selector ───────────────────────────
document.querySelectorAll(".fmt-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".fmt-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    selectedFormat = btn.dataset.fmt;
    // If we already have a result, re-render it in new format
    if (lastResult) renderResult(lastResult);
  });
});

// ── Paste button ──────────────────────────────
document.getElementById("btn-paste").addEventListener("click", async () => {
  try {
    const text = await navigator.clipboard.readText();
    rawInput.value = text;
  } catch {
    rawInput.focus();
    document.execCommand("paste");
  }
});

// ── Save API key ──────────────────────────────
document.getElementById("btn-save-key").addEventListener("click", () => {
  const key = apiKeyInput.value.trim();
  if (!key) return;
  chrome.storage.local.set({ geminiApiKey: key }, () => {
    const btn = document.getElementById("btn-save-key");
    btn.textContent = "✓";
    setTimeout(() => (btn.textContent = "Save"), 1500);
  });
});

// ── Normalize button ──────────────────────────
document.getElementById("btn-normalize").addEventListener("click", () => {
  const raw = rawInput.value.trim();
  if (!raw) { rawInput.focus(); return; }

  const apiKey = apiKeyInput.value.trim();
  if (!apiKey) {
    alert("Please enter your Gemini API key in the settings below.");
    return;
  }

  showScreen("processing");
  normalizeAddress(raw, apiKey);
});

// ── Back button ───────────────────────────────
document.getElementById("btn-back").addEventListener("click", () => showScreen("main"));

// ── Copy buttons ─────────────────────────────
document.getElementById("btn-copy-main").addEventListener("click",
  () => copyText(resultDisplay.textContent));

document.getElementById("btn-copy-full").addEventListener("click",
  () => copyText(resultDisplay.textContent));

document.getElementById("btn-copy-json").addEventListener("click", () => {
  if (!lastResult) return;
  copyText(JSON.stringify(lastResult.components, null, 2));
});

document.getElementById("btn-copy-csv").addEventListener("click", () => {
  if (!lastResult) return;
  const c = lastResult.components;
  const headers = Object.keys(c).join(",");
  const values  = Object.values(c).map(v => `"${(v||"").replace(/"/g,'""')}"`).join(",");
  copyText(headers + "\n" + values);
});

function copyText(text) {
  navigator.clipboard.writeText(text).then(() => {
    copyConfirm.classList.remove("hidden");
    setTimeout(() => copyConfirm.classList.add("hidden"), 2000);
  });
}

// ══════════════════════════════════════════════
//  Gemini API call
// ══════════════════════════════════════════════
async function normalizeAddress(rawAddress, apiKey) {
  const country = document.getElementById("country-hint").value;

  procStatus.textContent = "Sending to Gemini AI…";

  const prompt = `You are an address parsing and normalization expert.

Given the raw address input below, normalize it into a clean, standardized format.
Country context: ${country}

Raw input:
"""
${rawAddress}
"""

Return ONLY valid JSON. No explanation. No markdown. No backticks.

JSON format:
{
  "normalized": {
    "usps":      "123 MAIN ST APT 4B\\nSPRINGFIELD IL 62701-1234",
    "multiline": "123 Main Street\\nApt 4B\\nSpringfield, IL 62701",
    "oneline":   "123 Main Street, Apt 4B, Springfield, IL 62701",
    "csv":       "123 Main Street,Apt 4B,Springfield,IL,62701,US"
  },
  "components": {
    "street_number": "123",
    "street_name":   "Main Street",
    "unit":          "Apt 4B",
    "city":          "Springfield",
    "state":         "IL",
    "zip":           "62701",
    "zip4":          "1234",
    "country":       "US"
  },
  "confidence": "high",
  "issues": []
}

Rules:
- confidence must be "high", "medium", or "low"
- "high" = address is clearly complete and valid
- "medium" = address is mostly clear but something is ambiguous (e.g. guessed zip code)
- "low" = significant information is missing or unclear
- "issues" is an array of short strings describing any problems found (empty array if none)
- For missing components use empty string ""
- USPS format: ALL CAPS, standard USPS abbreviations
- If zip+4 is unknown, just use zip without the +4
- Normalize abbreviations (St → Street, Ave → Avenue, etc.) in multiline/oneline
- For non-US addresses, adapt the format sensibly and note it in issues if needed`;

  try {
    const response = await fetch(`${GEMINI_API_URL}?key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
      }),
    });

    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error(err?.error?.message || `API error ${response.status}`);
    }

    procStatus.textContent = "Parsing response…";
    const data = await response.json();

    const rawText = data?.candidates?.[0]?.content?.parts
      ?.map(p => p.text || "").join("") || "";

    const clean  = rawText.replace(/```json|```/gi, "").trim();
    const parsed = JSON.parse(clean);

    if (!parsed.normalized || !parsed.components) {
      throw new Error("Unexpected response format.");
    }

    lastResult = parsed;
    renderResult(parsed);

  } catch (err) {
    console.error(err);
    showScreen("main");
    alert(`Normalization failed: ${err.message}\n\nCheck your API key and try again.`);
  }
}

// ══════════════════════════════════════════════
//  Render result screen
// ══════════════════════════════════════════════
function renderResult(parsed) {
  // Main formatted address
  const formatted = parsed.normalized[selectedFormat] || parsed.normalized.oneline;
  resultDisplay.textContent = formatted;

  // Confidence badge
  const conf = (parsed.confidence || "medium").toLowerCase();
  const confLabel = { high: "✓ High confidence", medium: "~ Medium confidence", low: "⚠ Low confidence" };
  confidenceBadge.textContent = confLabel[conf] || conf;
  confidenceBadge.className = "confidence-badge " + (conf === "high" ? "high" : conf === "medium" ? "medium" : "low");

  // Components
  const c = parsed.components || {};
  const componentDefs = [
    { key: "street_number", label: "Number" },
    { key: "street_name",   label: "Street" },
    { key: "unit",          label: "Unit / Apt" },
    { key: "city",          label: "City" },
    { key: "state",         label: "State" },
    { key: "zip",           label: "ZIP" },
    { key: "zip4",          label: "ZIP+4" },
    { key: "country",       label: "Country" },
  ];

  componentsGrid.innerHTML = "";
  componentDefs.forEach(({ key, label }) => {
    const val = c[key] || "";
    const item = document.createElement("div");
    item.className = "comp-item";
    item.innerHTML = `
      <div class="comp-label">${label}</div>
      <div class="comp-value ${val ? "" : "empty"}">${val || "—"}</div>
    `;
    componentsGrid.appendChild(item);
  });

  // Issues
  const issues = parsed.issues || [];
  if (issues.length > 0) {
    issuesBox.classList.remove("hidden");
    issuesList.innerHTML = "";
    issues.forEach(issue => {
      const li = document.createElement("li");
      li.textContent = issue;
      issuesList.appendChild(li);
    });
  } else {
    issuesBox.classList.add("hidden");
  }

  copyConfirm.classList.add("hidden");
  showScreen("result");
}
